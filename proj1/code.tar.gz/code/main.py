#!/usr/bin/python

from expert import *
from nature import *
from learner import *

import numpy as np
from numpy import average
import matplotlib.pyplot as plt

def run(learner, nature, number_round): 
  """run the specified learner with the specified nature for a specific number of rounds."""
  regrets, losses = [], []
  # yep, just iterate that many times.  
  for index in range(0, number_round - 1): 
    # 1. the nature produces an observation
    observation = nature.observe() 
    # 2. the learner receives the observation and makes a prediction.
    prediction = learner.predict(**observation)
    # 3. the nature labels the observation possibly by peeking at the learner.  
    true_label = nature.label(learner = learner, **observation) 
    # 4. the learner updates the weights of its experts and returns the loss.
    losses.append(learner.update(true_label))
    # 5. save the regret this round for all the experts
    regrets.append(learner.regrets()) 
  
  return losses, regrets 

def plot(losses, regrets): 
  """plot the accumulative losses and the accumulative regrets."""
  # plot the regrets
  figure, axe1 = plt.subplots()
  figure.set_size_inches(12, 4, forward = True)
  axe1.plot(regrets, 'r-', label = 'Regrets') 
  axe1.set_ylabel('Regret')
  axe1.legend(loc = 2) 
  # plot the losses
  axe2 = axe1.twinx()
  axe2.plot(losses, 'b--', label = 'Losses')
  axe2.set_ylabel('Loss') 
  axe2.legend(loc = 4)
  # show the results. 
  return figure

# some parameters and storage 
number_round = 1000
penalty = 0.5

# create a pool of experts. note that the experts can be assigned
# to multiple learners; their associated weights and predictions
# are maintained by their secrectaries.
experts_pool = [OptimisticExpert(), PessimisticExpert(), DualExpert()]

# instantiate a learner 
learner = RandomizedWeightedMajorityLearner(penalty) 
learner.enroll(*experts_pool)

# instantiate a nature
nature = TrialNature() 

# run a bunch of iterations. 
losses, regrets = run(learner, nature, number_round)

# note that the regrets here are not strictly regrets - they are just
# differences of losses of each round for each expert (i.e., 2d-array)
# to produce the actual regrets for the expert space, we first generate
# the cumulative sums of regrets with respect to the rounds, and then
# take the maximum over all the experts. 
losses_cum = np.cumsum(losses)
regrets_cum = np.amax(np.cumsum(regrets, axis = 0), axis = 1)

# plot the stuff. 
plot(losses_cum, regrets_cum)
plt.grid()
plt.show()

